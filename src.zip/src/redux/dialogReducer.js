
const ADD_MESSAGE = '/dialogReducer/ADD-MESSAGE';


let initialState = {
  Dialogs: [
    { id: 1, name: 'Arsh' },
    { id: 2, name: 'Alex' },
    { id: 3, name: 'Elen' },

  ],
  Messages: [
    { id: 1, message: 'hi' },
  ]
 },

  dialogReducer = (state = initialState, action) => {
    switch (action.type) {
      
      case ADD_MESSAGE:
        return {
          ...state,
          Messages: [...state.Messages, { id: 4, message: action.newMessageBody }],
          
        }
      default: return state;
    }

  }
export const addMessageCreater = (newMessageBody) => ({ type: ADD_MESSAGE ,newMessageBody})

export default dialogReducer;
// let stateCopy ={
  //   ...state,
  //   Messages:[...state.Messages],
  // };
  // stateCopy.newMessageBody = action.body,
   //stateCopy.Messages.push({ id: 4, message: stateCopy.newMessageBody });
      //stateCopy.newMessageBody = '';
      //   if (action.type === ONCHANGE_MESSAGE_BUTTON) {
  //     state.newMessageBody = action.body;

  //   }else if ( action.type ===ADD_MESSAGE ) {
  //     state.Messages.push({id:4 ,message:state.newMessageBody });
  //     state.newMessageBody = '';

  //   return state;
  // }

// case ONCHANGE_MESSAGE_BUTTON:
      //   return {
      //     ...state,
      //     newMessageBody: action.body,
      //   }
  //     export const onChangeMessageButtonCreater = (text) =>
  // ({ type: ONCHANGE_MESSAGE_BUTTON, body: text })
  //const ONCHANGE_MESSAGE_BUTTON = 'ONCHANGE-MESSAGE-BUTTON';
import profileReducer, { addPostCreater } from "./profileReducer";


let state = {
  Posts: [
    { id:1, message: 'Hay my name is Armen', like: "789" },

  ],
  
  
};
  it ('newpost',()=>{
   let  action=addPostCreater ('heyhey')
   let newState = profileReducer (state, action)
  

 
expect(newState.Posts.length).toBe(2)
});
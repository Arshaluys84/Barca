 import {  BrowserRouter, Route, withRouter } from 'react-router-dom';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import News from './components/News/News';
import Music from './components/Music/Music';
import Settings from './components/Settings/Settings'
import store from './redux/redux-store'
import UsersContainer from './components/Users/UsersContainer';
import ProfileContainer from './components/Profile/ProfileContainer';
import HeaderContainer from './components/Header/HeaderContainer';
import Login from './components/login/login';
import React  from 'react';
import { connect ,Provider} from 'react-redux';
import { compose } from 'redux';
import {initializeApp} from './redux/appReducer'
import Preloader from './components/common/Preloader';
import { WithSuspense } from './hoc/withSuspense';
const DialogsContainer =React.lazy (()=>import('./components/Dialogs/DialogsContainer'))
//import DialogsContainer from './components/Dialogs/DialogsContainer';

class App extends React.Component  {
  componentDidMount() {
    this.props.initializeApp ()
  }
  render(){
   if  (!this.props.initialized){
      return  <Preloader />
    
     }
    
  return (
  //  <BrowserRouter  >
      <div className="App">
        <HeaderContainer/>
        <Navbar />
        <div className="AppContent">
          <Route path="/Profile/:userId?" render={()=><ProfileContainer
         
           />}/> 
             <Route path="/Dialogs" render={WithSuspense ( DialogsContainer)} 
            //  {()=>{
            // return  <React.Suspense fallback={<Preloader/>}>
            
            //  <DialogsContainer  />
          
            //  </React.Suspense>}} 
            />  
            
           <Route path="/Users" render={()=><UsersContainer/>} />
           <Route path="/News" render={()=><News/>} />
          <Route path="/Music" render={()=><Music/>} />
          <Route path="/Settings" render={()=><Settings/>} /> 
          <Route path="/Login" render={()=><Login/>} /> 
        </div>
      </div>
  //  </BrowserRouter>
  );
             }
};
const mapStateToProps=(state)=>{
  return{
    initialized:state.app.initialized,
  }
}
const AppContainer= compose (
  withRouter,
  connect(mapStateToProps, { initializeApp }))(App)

  const MainApp =(props)=>{
   
  return  <BrowserRouter basename={process.env.PUBLIC_URL} >
   <Provider store={store}>
       <AppContainer />
      </Provider>
    </BrowserRouter>
 
  }
  export default MainApp;
 
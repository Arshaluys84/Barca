import React from 'react';
import s from './News.module.css'


const News =(props) =>{
    return (
        <div className={s.News}>
            Latest News
        </div>
    )
}

export default News;
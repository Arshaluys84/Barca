import React from 'react';
import { NavLink } from 'react-router-dom';
import s from './Header.module.css'

const Header = (props)=>{
  
    return (
        <div className={s.header}>
          <div className={s.headerImg}>
              <img src="https://s1.1zoom.me/big0/980/Logo_Emblem_Footbal_FC_Barcelona_Barca_Emblem_589404_1280x800.jpg" alt="Barca" />
          </div>
           <div className={s.nameBar}>
                     BARCELONA
            </div>
            <div className={s.loginBlock}>
            {   props.isAuth ?
            <div>    {props.login}<button onClick={props.logout}>Log out</button>
              </div>  
              : <NavLink to="/login">Login</NavLink>  }
              {console.log(props.logout)}
            </div>
        </div>
      
    )
}

export default Header;

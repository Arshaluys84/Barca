import React from 'react';
import s from './Settings.module.css'


const Settings =(props) =>{
    return (
        <div className={s.Settings}>
           My Settings
        </div>
    )
}

export default Settings;
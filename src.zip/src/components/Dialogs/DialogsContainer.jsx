
import { connect } from 'react-redux';
import { compose } from 'redux';
import {  withAuthRedirect,  } from '../../hoc/withAthRedirect';
import { addMessageCreater} from '../../redux/dialogReducer';
import Dialogs from './Dialogs';

const mapStateToProps = (state) => {
    return {
        DialogsPage: state.DialogsPage,
      
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        // onChangeMessageButton: (text) => {
        //     dispatch(onChangeMessageButtonCreater(text))
        // },
        addMessage: (newMessageBody) => {
            dispatch(addMessageCreater(newMessageBody))
        },
    }
}


export default compose (
    connect(mapStateToProps, mapDispatchToProps),
    withAuthRedirect
)(Dialogs)

// const DialogsContainer = () => {


//     return (
//         <StoreContext> 
//              {  (store)  => {
//                  let state = store.getState();
//                  let addMessage = () => {
//                     store.dispatch(addMessageCreater())
//                 }
//                 let onChangeMessageButton = (text) => {
//                     store.dispatch(onChangeMessageButtonCreater(text));
//                 }


//     return      <Dialogs addMessage={addMessage} onChangeMessageButton={onChangeMessageButton}
//                 state={state.DialogsPage} />
//             }  } 
//             </StoreContext>
//     )
// }
// const DialogsContainer = withAuthRedirect (connect(mapStateToProps, mapDispatchToProps)(Dialogs));
// export default DialogsContainer;

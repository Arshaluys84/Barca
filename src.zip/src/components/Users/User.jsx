import React from 'react'
import s from './Users.module.css'
import userPhoto from './../assets/userPhoto.jpg'
import { NavLink } from 'react-router-dom';
const User = ({ user, followingprocess, unfollow, follow }) => {

    return (

        <div className={s.users} >

            <span className={s.spans}>
                <div>
                    <NavLink to={'/Profile/' + user.id}>
                        <img src={user.photos.small != null ? user.photos.small : userPhoto} alt="ava" />
                    </NavLink>
                </div>
                <div>

                    {user.followed
                        ? <button disabled={followingprocess.some(id => id === user.id)} onClick={() => {
                            //  props.setFollowingProcess(true,u.id)

                            //  UsersAPI.unfollower(u.id)
                            //              .then(response => {
                            //          if(response.data.resultCode === 0) {
                            //       props.unfollow(u.id)
                            //           props.setFollowingProcess(false,u.id)
                            //        }
                            //                 })    
                            unfollow(user.id)

                        }}>unfollow</button> :
                        <button disabled={followingprocess.some(id => id === user.id)} onClick={() => {
                            //              props.setFollowingProcess(true,u.id)

                            //       UsersAPI .follower(u.id)                          
                            //         .then(response => {
                            //     if(response.data.resultCode === 0) {

                            //     props.follow(u.id)
                            //     props.setFollowingProcess(false,u.id)
                            //    }
                            //        })
                            follow(user.id)
                        }}>follow</button>
                    }
                </div>
            </span>
            <span >
                <span className={s.spans}>
                    <div className={s.firstColumn}>
                        {user.name}
                    </div>
                    <div className={s.firstColumn}>
                        {user.status}
                    </div>
                </span>
                <span >
                    <div>{'user.location.country'}</div>
                    <div>{'user.location.citiname'}</div>
                </span>
            </span>
        </div>

    )
}
export default User;

 // axios

                                        //      .delete(`https://social-network.samuraijs.com/api/1.0/follow/${u.id}` ,{
                                        //          withCredentials:true,
                                        //         headers:{
                                        //              "API-KEY":"78e76ec9-f734-415f-a64d-335bb16d92d5"
                                        //          }
                                        //       })
                                        // postFollow(props.id)
                                            // .then(response => {
                                            //     if(response.resultCode === 0) {

                                            //     props.follow(u.id)
                                            //    }
                                            //        })
                                            //              }}>follow</button>
                                            //                         }
        //                                           axios

        //  .post(`https://social-network.samuraijs.com/api/1.0/follow/${u.id}` ,{},{
        //     withCredentials:true,
        //      headers:{
        //          "API-key":"78e76ec9-f734-415f-a64d-335bb16d92d5"
        //     }
        //  })
        // let pageCount = Math.ceil(props.totalCount / props.count);
    // let pages = [];
    // for (let index = 1; index <= pageCount; index++) {
    //     pages.push(index);
    // }
/* {
            <div className={s.pagesSpans}>{pages.map(p => {
                return <span  className={props.currentPage === p ? s.selectedPage :undefined}
                    onClick={(e) => { props.onChanged(p) }} key={p.id}>{p}</span>
            })}
            </div>} */
import { connect } from 'react-redux';
import {  setUsers, setCurrentPage, follow,unfollow, setTotalCount, setPreloader, getUsers, getCurrentUsers  } from '../../redux/usersReducer';
import React from 'react'
import UsersPure from './UsersPure'
import Preloader from '../common/Preloader';
import { compose } from 'redux';
import { withAuthRedirect } from '../../hoc/withAthRedirect';
import { getUsersSelector ,getTotalCount , getCount ,getCurrentPage,getIsFetching, getFollowingprocess} from '../../redux/selectors';

class UsersContainer extends React.Component {

    componentDidMount() {
       this.props.getUsers(this.props.currentPage,this.props.count,this.props.totalCount)
        
    };

    onChanged = (pn) => {
        
        this.props.getCurrentUsers(pn,this.props.count)

    }

    render() {
        return (
            <>
                {this.props.isFetching ? <Preloader /> : null}
                <UsersPure onChanged={this.onChanged}
                    users={this.props.users}
                    totalCount={this.props.totalCount}
                    count={this.props.count}
                    follow={this.props.follow}
                    unfollow={this.props.unfollow}
                    currentPage={this.props.currentPage}
                    followingprocess={this.props.followingprocess}
                    
                    
                />
            </>
        )
    }
}
let mapStateToProps = (state) => {
    return {
        users: getUsersSelector (state),
       
        totalCount: getTotalCount(state),
        count: getCount(state),
        currentPage: getCurrentPage(state),
        isFetching: getIsFetching(state),
        followingprocess:getFollowingprocess(state),
    };
};
let mapDispatchToProps = {
    follow,
    unfollow,
    setUsers,
    setCurrentPage,
    setTotalCount,
    setPreloader,
    getUsers,
    getCurrentUsers
   
    
   
};

//export default connect(mapStateToProps, mapDispatchToProps)(UsersContainer);

export default compose(
    connect(mapStateToProps, mapDispatchToProps),
    withAuthRedirect,
)(UsersContainer)




// this.props.setPreloader(true)
        // UsersAPI.getUsers(this.props.currentPage, this.props.count)
        //     .then(response => {

        //         this.props.setUsers(response.items)
        //         console.log(response.data)
        //         this.props.setTotalCount(Math.ceil(response.totalCount / 200))

        //     })
        // this.props.setPreloader(false)
        // this.props.setCurrentPage(pn)
        // this.props.setPreloader(true)
        // UsersAPI.getUsers(pn, this.props.count)
        //     .then(response => {
        //         this.props.setUsers(response.items)
        //         this.props.setPreloader(false)
        //     })
        // let mapStateToProps = (state) => {
        //     return {
        //         users: getUsersSelector (state),
        //         //.UsersPage.users,
        //         totalCount: state.UsersPage.totalCount,
        //         count: state.UsersPage.count,
        //         currentPage: state.UsersPage.currentPage,
        //         isFetching: state.UsersPage.isFetching,
        //         followingprocess:state.UsersPage.followingprocess,
        //     };
        // };
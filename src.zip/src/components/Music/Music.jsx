import React from 'react';
import s from './Music.module.css'


const Music =(props) =>{
    return (
        <div className={s.Music}>
            Best Music
        </div>
    )
}

export default Music;
import React,{useState} from 'react';
import Preloader from '../../common/Preloader';
import s from './ProfileInfo.module.css';
import anonim from '../../assets/anonim.png';
//import ProfileStatus from './ProfileStatus';
import ProfileStatusWithHook from './ProfileStatusWithHook';
import ProfileDataFormRedux from './ProfileDataForm';


const ProfileInfo = (props) => {
  let [editMode,setEditMode]=useState(false)
  if (!props.profile) {
    return <Preloader />
  }
  const OnupdatePhoto = (e) => {

    if (e.target.files.length) {

      props.updatePhoto(e.target.files[0])
    }
  }
   let onSubmit= async(formData)=>{
   // formData.preventDefault();
    //  await props.saveProfile(formData)
  //  setEditMode(false)
    props.saveProfile(formData).then((...rest)=> {
          // console.log({rest})
          setEditMode(false)
        })
       
      
      
    //  console.log(formData)
   }
  return (

    <div className={s.profile}>
      {/* <div className={s.profileImg}>
        <img src="https://i.ytimg.com/vi/kI287mu4gc8/maxresdefault.jpg" alt="Barca" />
      </div> */}
      <div className={s.description}>
        <div>
         
          <img src={props.profile.photos.large || anonim} alt={`${props.profile.userId}   must be here`} />
          {props.isOwner && <input type="file" onChange={OnupdatePhoto} />}
          
          <ProfileStatusWithHook {...props} status={props.status} updateStatus={props.updateStatus} />
         {editMode ?
          <ProfileDataFormRedux initialValues={props.profile} onSubmit={onSubmit} profile={props.profile}/>
         : <ProfileData profile={props.profile} isOwner={props.isOwner}
          goToEditMode={()=>{setEditMode(true)}}/>}
        </div>
      </div>
    </div>
  )

}
const Contacts = ({ contactName, contactValue }) => {
  return <div>
    {contactName} :{contactValue}
  </div>
}

const ProfileData =({profile,isOwner,goToEditMode})=>{
  return <div>
    {isOwner && <button onClick={goToEditMode}>EDIT</button>}
  <div>FullName:{profile.fullName}</div>
  <div>{profile.userId}</div>
  <div>lookingForAJob:{profile.lookingForAJob ? "yes" : "no"}</div>
  <div>lookingForAJobDescription:{profile.lookingForAJobDescription}</div>
  <div>aboutMe:{profile.aboutMe}</div>
  <div>Contacts:{Object.keys(profile.contacts).map(key => {
    return <Contacts key={key} contactName={key}
      contactValue={profile.contacts[key]} />
  })}</div>
</div>
}
// const ProfileDataForm =({profile})=>{
//   return <div>
//     {/* {props.isOwner && <button onChange={goToEditMode}>EDIT</button>}
//   <div>FullName:{props.profile.fullName}</div>
//   <div>{props.profile.userId}</div>
//   <div>lookingForAJob:{props.profile.lookingForAJob ? "yes" : "no"}</div>
//   <div>lookingForAJobDescription:{props.profile.lookingForAJobDescription}</div>
//   <div>aboutMe:{props.profile.aboutMe}</div>
//   <div>Contacts:{Object.keys(props.profile.contacts).map(key => {
//     return <Contacts key={key} contactName={key}
//       contactValue={props.profile.contacts[key]} />
//   })}</div> */}
//   Form
// </div>
// }
export default ProfileInfo;

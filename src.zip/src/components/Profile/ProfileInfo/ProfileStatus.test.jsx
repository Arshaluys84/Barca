import React from "react";
import { create } from "react-test-renderer";
import ProfileStatus from "./ProfileStatus";

describe("status will be here", () => {
  test("Matches the snapshot", () => {
    const button = create(<ProfileStatus status="aaa" />);
    const instance = component.getInstance();
    expect(instance.state.status).toBe("aaa");
  });
});


import { connect } from 'react-redux';
import { addPostCreater } from '../../../redux/profileReducer';
import Myposts from './Myposts';
const mapStateToProps =(state)=>{
  return {
    Posts:state.ProfilePage.Posts,
    newPostText:state.ProfilePage.newPostText,
  }
};
const mapDispatchToProps=(dispatch)=>{
  return {
    addPost:(newPostText)=>{
      dispatch(addPostCreater(newPostText))
    },
    
  }
}
const MypostsContainer=connect(mapStateToProps,mapDispatchToProps)(Myposts);
export default MypostsContainer;
// const MypostsContainer = () => {

//   return (
//     <StoreContext.Consumer>
//       {  (store) => {
//         let state = store.getState();
//         let addPost = () => {
//           store.dispatch(addPostCreater())
//         }
//         let onChangePostButton = (text) => {
//           // let text = e.target.value;
//           store.dispatch(onChangePostButtonCreater(text));
//         }

//         return <Myposts addPost={addPost} onChangePostButton={onChangePostButton}
//           Posts={state.ProfilePage.Posts}
//           newPostText={state.ProfilePage.newPostText} />
//       }}
//     </StoreContext.Consumer>
//   )
// };
// onChangePostButton:(text)=>{
//   dispatch(onChangePostButtonCreater(text))
// }